-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 25, 2008 at 03:34 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php_class_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_test`
--

CREATE TABLE IF NOT EXISTS `tbl_user_test` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_login` varchar(55) default NULL,
  `pass_word` varchar(255) default NULL,
  `address` text,
  `email` varchar(255) default NULL,
  `gender` enum('Male','Female') default NULL,
  `heard_from` varchar(255) default NULL,
  `newsletter` enum('Yes','No') default NULL,
  `created_on` datetime default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_user_test`
--

INSERT INTO `tbl_user_test` (`user_id`, `user_login`, `pass_word`, `address`, `email`, `gender`, `heard_from`, `newsletter`, `created_on`, `modified_on`) VALUES
(1, 'user1', 'pass1', 'An address, of this, city, country', 'user1@domain1.com', 'Male', 'Google', 'Yes', '2008-12-23 04:42:50', '2008-12-23 04:42:50'),
(2, 'user123', 'pass123', 'here is , an address, of the city,', 'user123m@domail.com', 'Female', 'Google', 'Yes', '2008-12-23 04:52:14', '2008-12-25 03:26:57'),
(3, 'ram', 'ram321', 'Gha 2-115, Balaju\r\nKathmandu, Nepal', 'ram@mymail.com', 'Male', 'Google', 'Yes', '2008-12-23 13:34:16', '2008-12-23 13:34:16'),
(4, 'Shyam', 'passme', '1234 house, 45th Street\r\nA city, A Country', 'shyam@gmail.com', 'Male', 'This website user', 'Yes', '2008-12-23 13:42:36', '2008-12-23 13:42:36'),
(5, 'Richard', 'rich123', '47th Avenues Street, 11245\r\nNew York City, 56898\r\nUnited States', 'richard@richardmail.com', 'Male', 'Other Website', 'Yes', '2008-12-25 02:12:00', '2008-12-25 02:12:00'),
(6, 'Anotheruser', 'user1234', 'A street, city\r\nCountry,', 'anotherusr@mail.com.np', 'Male', 'Friends or Family', 'No', '2008-12-25 02:20:25', '2008-12-25 02:20:25');
