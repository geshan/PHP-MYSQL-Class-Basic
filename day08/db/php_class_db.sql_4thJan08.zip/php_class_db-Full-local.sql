-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 04, 2009 at 03:43 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php_class_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client`
--

CREATE TABLE IF NOT EXISTS `tbl_client` (
  `client_id` int(10) unsigned NOT NULL auto_increment,
  `first_name` varchar(55) NOT NULL,
  `middle_name` varchar(55) default NULL,
  `last_name` varchar(55) default NULL,
  `created_on` datetime default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`client_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_client`
--

INSERT INTO `tbl_client` (`client_id`, `first_name`, `middle_name`, `last_name`, `created_on`, `modified_on`) VALUES
(1, 'Ram', 'Kumar', 'Shrestha', '2008-12-30 16:12:50', '2008-12-30 16:12:56'),
(2, 'Hari', NULL, 'Tamang', '2008-12-30 16:13:07', '2008-12-30 16:13:14'),
(3, 'John', NULL, 'White', '2008-12-30 16:14:29', '2008-12-30 16:14:34'),
(4, 'Sachin', 'R', 'Tendulkar', '2008-12-30 16:15:16', '2008-12-30 16:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_log`
--

CREATE TABLE IF NOT EXISTS `tbl_log` (
  `log_id` double NOT NULL auto_increment,
  `tbl_user_test_user_id` int(10) unsigned NOT NULL,
  `log_text` text,
  PRIMARY KEY  (`log_id`),
  KEY `tbl_log_FKIndex1` (`tbl_user_test_user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_log`
--

INSERT INTO `tbl_log` (`log_id`, `tbl_user_test_user_id`, `log_text`) VALUES
(1, 1, 'Changed password.'),
(2, 1, 'Edited details.'),
(3, 2, 'Added new user'),
(4, 2, 'edited password for another user.'),
(5, 1, 'Added a new user.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE IF NOT EXISTS `tbl_products` (
  `id` varchar(30) NOT NULL default '',
  `name` varchar(60) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `price` decimal(10,2) NOT NULL default '0.00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`id`, `name`, `type`, `price`) VALUES
('123451', 'Park''s Great Hits', 'Music', 19.99),
('123452', 'Silly Puddy', 'Toy', 3.99),
('123453', 'Playstation', 'Toy', 89.95),
('123454', 'Men''s T-Shirt', 'Clothing', 32.50),
('123455', 'Pant', 'Clothing', 34.97),
('123456', 'Electronica 2002', 'Music', 3.99),
('123457', 'Country Tunes', 'Music', 21.55),
('123458', 'Watermelon', 'Food', 8.73);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_test`
--

CREATE TABLE IF NOT EXISTS `tbl_user_test` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_login` varchar(55) default NULL,
  `pass_word` varchar(255) default NULL,
  `address` text,
  `email` varchar(255) default NULL,
  `gender` enum('Male','Female') default NULL,
  `heard_from` varchar(255) default NULL,
  `newsletter` enum('Yes','No') default NULL,
  `created_on` datetime default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_user_test`
--

INSERT INTO `tbl_user_test` (`user_id`, `user_login`, `pass_word`, `address`, `email`, `gender`, `heard_from`, `newsletter`, `created_on`, `modified_on`) VALUES
(1, 'user1', 'pass1', 'An address, of this, city, country', 'user1@domain1.com', 'Male', 'Google', 'Yes', '2008-12-23 04:42:50', '2008-12-23 04:42:50'),
(2, 'user123', 'pass123', 'here is , an address, of the city,', 'user123m@domail.com', 'Female', 'Google', 'Yes', '2008-12-23 04:52:14', '2008-12-25 03:26:57'),
(3, 'ram', 'ram321', 'Gha 2-115, Balaju\r\nKathmandu, Nepala', 'ram@mymail.com', 'Male', 'Google', 'Yes', '2008-12-23 13:34:16', '2009-01-02 04:32:06'),
(4, 'Shyam', 'passme', '1234 house, 45th Street\r\nA city, A Country', 'shyam@gmail.com', 'Male', 'This website user', 'Yes', '2008-12-23 13:42:36', '2008-12-23 13:42:36'),
(5, 'Richard', 'rich123', '47th Avenues Street, 11245\r\nNew York City, 56898\r\nUnited States', 'richard@richardmail.com', 'Male', 'Other Website', 'Yes', '2008-12-25 02:12:00', '2008-12-25 02:12:00'),
(6, 'Anotheruser', 'user1234', 'A street, city\r\nCountry,', 'anotherusr@mail.com.np', 'Male', 'Friends or Family', 'No', '2008-12-25 02:20:25', '2008-12-25 02:20:25');
